﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using AssetsTools.NET;
using AssetsTools.NET.Extra;
using System.Windows.Forms;

namespace ConsoleApp1
{
    public class TestReading
    {
        public BundleFileInstance bundleInst;
        public AssetBundleFile bundleFile;
        public AssetsManager helper;
        public List<AssetDetails> assets;

        public TestReading(string filename)
        {
        }



        public void Unpack(string filename)
        { 
            helper = new AssetsManager();
            if (!File.Exists("classdata.tpk"))
                MessageBox.Show("classdata.tpk could not be found. Make sure it exists and restart.", "Assets View");
            helper.LoadClassPackage("classdata.tpk");

            string unpackedFilename = Path.GetDirectoryName(filename) + "\\" + Path.GetFileName(filename) + ".unpacked";

            if (!File.Exists(unpackedFilename))
            {
                Console.WriteLine("unpacking");
                bundleInst = helper.LoadBundleFile(filename, false);
                bundleFile = bundleInst.file;
                uint compressionMethod = bundleFile.bundleHeader6.GetCompressionType();

                //return 3
                if (compressionMethod > 0)
                {
                    using (Stream stream = File.Open(filename + ".unpacked", FileMode.Create, FileAccess.ReadWrite))
                    {
                        try
                        {
                            bundleFile.reader.Position = 0;
                            bundleFile.Unpack(bundleFile.reader, new AssetsFileWriter(stream));
                            stream.Position = 0;
                            bundleFile = new AssetBundleFile();
                            bundleFile.Read(new AssetsFileReader(stream), false);
                            bundleInst.file = bundleFile;
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.ToString());
                        }
                    }
                }
                Console.WriteLine("ok");
            }

            if (File.Exists(unpackedFilename))
            {
                Readtest(unpackedFilename);
            }
        }

        void Readtest(string filename)
        {
            bundleInst = helper.LoadBundleFile(filename, false);
            bundleFile = bundleInst.file;

            BundleHelper.UnpackInfoOnly(bundleFile);
            uint compressionMethod = bundleFile.bundleHeader6.GetCompressionType();



            //if (compressionMethod > 0) throw new Exception("is compressed");


            List<byte[]> files = BundleHelper.LoadAllAssetsDataFromBundle(bundleFile);

            if (files.Count != 1) return;

            MemoryStream mainStream = new MemoryStream(files[0]);

            string mainName = bundleFile.bundleInf6.dirInf[0].name;

            AssetsFileInstance mainInst = helper.LoadAssetsFile(mainStream, mainName, false);
            mainInst.parentBundle = bundleInst;

            LoadMainAssetsFile(mainInst);

        }


        public void LoadMainAssetsFile(AssetsFileInstance inst)
        {
            inst.table.GenerateQuickLookupTree();
            helper.UpdateDependencies();
            helper.LoadClassDatabaseFromPackage(inst.file.typeTree.unityVersion);
            if (helper.classFile == null)
            {
                //may still not work but better than nothing I guess
                //in the future we should probably do a selector
                //like uabe does
                List<ClassDatabaseFile> files = helper.classPackage.files;
                helper.classFile = files[files.Count - 1];
            }
            LoadGeneric(inst, false);
            
        }

        private void LoadGeneric(AssetsFileInstance mainFile, bool isLevel)
        {
            assets = new List<AssetDetails>();
            foreach (AssetFileInfoEx info in mainFile.table.assetFileInfo)
            {
                ClassDatabaseType type = AssetHelper.FindAssetClassByID(helper.classFile, info.curFileType);
                if (type == null)
                    continue;
                string typeName = type.name.GetString(helper.classFile);
                if (typeName != "GameObject" && isLevel)
                    continue;
                string name = AssetHelper.GetAssetNameFast(mainFile.file, helper.classFile, info);


                AssetDetails details = new AssetDetails(new AssetPPtr(0, info.index), name, typeName, (int)info.curFileSize);

                assets.Add(details);
            }
            //rootDir = new FSDirectory();
            //rootDir.Create(assets);
            //ChangeDirectory("");
        }
        public class AssetDetails
        {
            public AssetPPtr pointer;
            public string path;
            public string type;
            public int size;
            public AssetDetails(AssetPPtr pointer, string path = "", string type = "", int size = 0)
            {
                this.pointer = pointer;
                this.path = path;
                this.type = type;
                this.size = size;
            }

            public override string ToString()
            {
                return string.Format("{0} , {1} , {2} , {3}", pointer, path, type, size);
            }
        }
    }
}
