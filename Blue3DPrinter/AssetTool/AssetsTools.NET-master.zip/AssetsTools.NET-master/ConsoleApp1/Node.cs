﻿using AssetsTools.NET;
using System;
using System.Diagnostics;
using System.Collections.Generic;


namespace ConsoleApp1
{
    public class Node
    {
        public Node Parent;
        public List<Node> Children;
        public object Tag;
        public string Name;

        int level;

        public Node(Node Parent, string name , int nodeLevel = 0, object tag = null)
        {
            this.Parent = Parent;
            if (Parent != null)
            {
                if (Parent.Children == null) Parent.Children = new List<Node>();
                Parent.Children.Add(this);
            }
            Tag = tag;
            Name = name;
            level = nodeLevel;

            if (tag is AssetTypeValueField baseField) DebugField(baseField);
        }

        void DebugField(AssetTypeValueField baseField)
        {
            Debug.IndentLevel = level;
            Debug.WriteLine("NODE " + Name);

            AssetTypeValueField components = baseField.Get("m_Component").Get("Array");
            int componentSize = components.GetValue().AsArray().size;

            foreach (var child in baseField.children)
            {
                Debug.WriteLine(child.GetName());
            }
            Debug.WriteLine("");

        }

        public override string ToString()
        {
            return Name;
        }

    }
}
