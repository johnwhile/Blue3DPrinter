﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using AssetsTools.NET;
using AssetsTools.NET.Extra;

namespace ConsoleApp1
{

    public partial class Form1 : Form
    {
        AssetsManager manager;

        static string[] GameBundle = new string[]
        {
            //@"D:\Users\john\Progetti\Empyrion\Models\models.uncompressed",
            //@"D:\Users\john\Progetti\Empyrion\Models\models2.uncompressed",
            @"D:\Users\john\Progetti\Empyrion\Models\shapes.uncompressed"
        };
        
        
        public Form1()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

             manager = new AssetsManager();
            List<AssetsFileInstance> bundles = LoadAllBundles(GameBundle);

            Console.WriteLine("test read one model");


            int instIndex;
            long pathID;

            (instIndex, pathID) = Search(bundles, "RampConnectorDright");

            if (instIndex >= 0)
            {
                GetModel(bundles[instIndex], pathID);
            }
        }


        List<AssetsFileInstance> LoadAllBundles(string[] bundles)
        {
            List<AssetsFileInstance> list = new List<AssetsFileInstance>(bundles.Length);

            foreach(string filename in bundles)
            {
                Console.WriteLine("load bundles " + Path.GetFileName(filename));
                //set to false to prevent automatically decompressing to memory
                BundleFileInstance bundleInst = manager.LoadBundleFile(filename, false);
                AssetBundleFile bundleFile = bundleInst.file;
                //compressed bundles not work
                if (bundleFile.bundleHeader6.GetCompressionType() > 0) continue;
                //CAB-2361726316572371623176273617623176238617236123 
                string mainName = bundleFile.bundleInf6.dirInf[0].name;

                Console.WriteLine("load first asset from bundle");
                list.Add(manager.LoadAssetsFileFromBundle(bundleInst, 0));
            }
            return list;
        }


        (int instanceIndex, long pathID) Search(List<AssetsFileInstance> assetList, string objectName = "RampConnectorDright", bool caseSensitive = false)
        {
            AssetFileInfoEx info = null;
            int i = 0;
            //if there are multiple assets by the same name, you can use type to narrow it down
            while (i < assetList.Count && (info = assetList[i].table.GetAssetInfo(objectName, (int)AssetClassID.GameObject, caseSensitive)) == null) { i++; };

            if (info != null)
            {
                //the pathID
                return (i, info.index);
            }
            return (-1, 0);
        }


        public void GetModel(AssetsFileInstance inst, long pathID)
        {
            AssetFileInfoEx info = inst.table.GetAssetInfo(pathID);
            
            string name = AssetHelper.GetAssetNameFastNaive(inst.table.file, info);

            AssetTypeTemplateField typeTemplate = manager.GetTemplateBaseField(inst.file, info);
            
            string typeName = typeTemplate.type;
            
            AssetExternal firstExt = manager.GetExtAsset(inst, 0, pathID);
            AssetExternal rootExt = GetRootGameObject(firstExt);

            Node root = null;
            PopulateHierarchyTree(inst, ref root, 0, rootExt);

        }
        private void PopulateHierarchyTree(AssetsFileInstance inst, ref Node parent, int level, AssetExternal ext)
        {
            // basefield children contain:
            /*
                m_Component
                m_Layer
                m_Name
                m_Tag
                m_IsActive
            */
            AssetTypeValueField baseField = ext.instance.GetBaseField();
            long thisId = ext.info.index;

            Node node;

            if (parent == null)
            {
                node = new Node(null, baseField.Get("m_Name").GetValue().AsString(), level, baseField);
                parent = node;
            }
            else
                node = new Node(parent, baseField.Get("m_Name").GetValue().AsString(), level, baseField);

            if (!baseField.Get("m_IsActive").GetValue().AsBool()) ;


            //get last children
            AssetTypeValueField lastchild = ext.instance.GetBaseField().Get("m_Component").Get("Array")[0];
            lastchild = lastchild.children[lastchild.childrenCount - 1];


            AssetTypeValueField children = manager.GetExtAsset(inst, lastchild).instance.GetBaseField().Get("m_Children").Get("Array");

            for (int i = 0; i < children.childrenCount; i++)
            {
                AssetExternal childExternal = manager.GetExtAsset(inst, children[i]);
                AssetExternal gameObjExt = manager.GetExtAsset(inst, childExternal.instance.GetBaseField().Get("m_GameObject"));
                PopulateHierarchyTree(inst, ref node, level + 1, gameObjExt);
            }
        }
        private AssetExternal GetRootGameObject(AssetExternal ext)
        {
            //get last children
            AssetTypeValueField lastchild = ext.instance.GetBaseField().Get("m_Component").Get("Array")[0];
            lastchild = lastchild.children[lastchild.childrenCount - 1];

            AssetExternal transformExt = manager.GetExtAsset(ext.file, lastchild);
            
            while (true)
            {
                AssetExternal parentExt = manager.GetExtAsset(ext.file, transformExt.instance.GetBaseField().Get("m_Father"));
                if (parentExt.instance == null)
                {
                    AssetExternal gameObjectExt = manager.GetExtAsset(ext.file, transformExt.instance.GetBaseField().Get("m_GameObject"));
                    return gameObjectExt;
                }
                transformExt = parentExt;
            }
        }


        public void DoSomething(AssetsFileInstance assetInst)
        {

            List<AssetDetails> assets = new List<AssetDetails>((int)assetInst.table.assetFileInfoCount);
            //all asset are GameObject
            foreach (var inf in assetInst.table.GetAssetsOfType((int)AssetClassID.GameObject))
            {
                AssetClassID id = (AssetClassID)inf.curFileType;
                string name = AssetHelper.GetAssetNameFastNaive(assetInst.table.file, inf);
                AssetDetails details = new AssetDetails(0, inf.index, name, id.ToString());
                assets.Add(details);
            }
        }
        public class AssetDetails
        {
            public string name;
            public string type;
            public int size;
            public int fileID;
            public long pathID;

            public AssetDetails(int fileID, long pathID, string path = "", string type = "", int size = 0)
            {
                this.pathID = pathID;
                this.fileID = fileID;
                this.name = path;
                this.type = type;
                this.size = size;
            }
        }
    }
}
